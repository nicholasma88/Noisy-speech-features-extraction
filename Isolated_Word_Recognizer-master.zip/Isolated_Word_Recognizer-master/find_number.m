function number=find_number(num)

if(num=='0' | num=='O')
    number='Oh';
elseif(num=='Z');
    number='Zero';
elseif(num=='1')
    number='One';
elseif(num=='2');
    number='Two';
elseif(num=='3');
    number='Three';
elseif(num=='4');
    number='Four';
elseif(num=='5');
    number='Five';
elseif(num=='6');
    number='Six';
elseif(num=='7');
    number='Seven';
elseif(num=='8');
    number='Eight';
elseif(num=='9');
    number='Nine';
end;
    